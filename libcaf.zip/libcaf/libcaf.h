#ifndef __LIBCAF_H__
#define __LIBCAF_H__

#include <stdint.h>

#define CAF_MAGIC_HEADER 0x46414323  
#define CAF_MAGIC_META   0x4154454D  
#define CAF_MAGIC_DATA   0x41544144  

#define CAF_MAX_CHUNK_SIZE 16777216

enum caf_error {
    CAF_OK = 0,
    CAF_ERROR = -1,
    CAF_INVALID_FILE = -2,
    CAF_FILE_NOT_OPENED = -3,
    CAF_UNKNOWN_CHUNK = -4,
    CAF_CHUNK_TOO_LARGE = -5
};

union magic_bytes {
    uint32_t value;
    char str[4];
};

struct caf_header {
    union magic_bytes magic;    
    uint16_t version;           
    uint16_t channels;          
    uint32_t sample_rate;       
    uint16_t bits_per_sample;   
};

struct caf_meta {
    char title[32];
    char artist[32];
    char year[4];
    uint8_t reserved[24];        
};

struct caf_chunk {
    union magic_bytes chunk_id;
    uint32_t chunk_size;
    union {
        struct caf_meta meta;
        int16_t *samples;
    } data;
};

struct caf_file {
    struct caf_header header;
    struct caf_meta metadata;
    size_t num_samples;
    int16_t *samples;
};

typedef struct caf_header caf_header;
typedef struct caf_meta caf_meta;
typedef struct caf_chunk caf_chunk;
typedef struct caf_file caf_file;


void caf_init(caf_file *file);
void caf_free(caf_file *file);
enum caf_error caf_read(caf_file *file, const char *filename);
enum caf_error caf_write(const caf_file *file, const char *filename);
void caf_print_info(const caf_file *file);

#endif
