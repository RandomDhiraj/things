#include <stdio.h>
#include <string.h>
#include <time.h>
#include <math.h>
#include "../../libcaf.h"

int main() {
    caf_file file;
    caf_init(&file);

    srand(time(NULL));

    file.header.magic.value = CAF_MAGIC_HEADER;
    file.header.version = 1;
    file.header.channels = 2;
    file.header.sample_rate = 44100;
    file.header.bits_per_sample = 16;

    strncpy(file.metadata.title, "Sample Track", 32);
    strncpy(file.metadata.artist, "CAF Project", 32);
    strncpy(file.metadata.year, "2023", 4);

    file.num_samples = 4096 + (rand() % 4096); 
    file.samples = calloc(file.num_samples, sizeof(int16_t));
    
    for(size_t i = 0; i < file.num_samples; i++) {
        double t = (double)i / file.header.sample_rate;
        file.samples[i] = (int16_t)(32767.0 * sin(2 * 3.14159 * 440.0 * t));
    }

    caf_write(&file, "sample.caf");
    
    caf_free(&file);
    return 0;
}
