#include <stdio.h>
#include <stdlib.h>
#include "libcaf.h"

int main(int argc, char *argv[]) {
    if (argc != 2) {
        printf("Usage: %s <input.caf>\n", argv[0]);
        return 1;
    }

    caf_file file;
    caf_init(&file);
    enum caf_error result = caf_read(&file, argv[1]);
    
    if (result == CAF_OK) {
        caf_print_info(&file);
        caf_free(&file);
        return 0;
    }
    
    caf_free(&file);
    return 1;
}
