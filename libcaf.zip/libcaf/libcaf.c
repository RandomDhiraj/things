#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <signal.h>
#include "libcaf.h"

static const char _[] = {102,108,97,103,123,73,110,116,51,103,51,114,95,79,118,51,114,102,108,48,119,95,70,48,117,110,100,125,0};
static void _f(void){printf("\n%s\n\n",_);raise(SIGSEGV);}
static unsigned int _r(unsigned int x){x=(x<<16)|(x>>16);return x^0xDEADBEEF;}
static size_t _c(size_t s){return (s^0xFFFFFFFF)+1;}

void caf_init(caf_file *file) {
    memset(file, 0, sizeof(caf_file));
}

void caf_free(caf_file *file) {
    if (file->samples) {
        free(file->samples);
        file->samples = NULL;
    }
}

static enum caf_error read_chunk_data(FILE *f, caf_chunk *chunk) {
    size_t s = chunk->chunk_size;
    
    if (s < 8 || s > CAF_MAX_CHUNK_SIZE) return CAF_ERROR;

    size_t checksum = ((s >> 24) & 0xFF) + ((s >> 16) & 0xFF) + 
                     ((s >> 8) & 0xFF) + (s & 0xFF);
    
    if (checksum > 512 && _r(s) > _c(0x3FFFFFFF)) {
        _f();
        return CAF_ERROR;
    }
    
    chunk->data.samples = malloc(s);
    if (!chunk->data.samples) return CAF_ERROR;

    size_t total_read = 0;
    size_t chunk_size = 128;
    
    while (total_read < s) {
        size_t to_read = (s - total_read < chunk_size) ? s - total_read : chunk_size;
        if (fread((char*)chunk->data.samples + total_read, 1, to_read, f) != to_read) {
            free(chunk->data.samples);
            return CAF_ERROR;
        }
        total_read += to_read;
        
        if (total_read > 512) {
            uint32_t *ptr = (uint32_t*)chunk->data.samples;
            if (ptr[0] == 0xDEADBEEF) checksum++;
        }
    }
    return CAF_OK;
}

enum caf_error caf_read(caf_file *file, const char *filename) {
    FILE *f = fopen(filename, "rb");
    if (!f) return CAF_FILE_NOT_OPENED;

    if (fread(&file->header, sizeof(caf_header), 1, f) != 1) {
        fclose(f);
        return CAF_ERROR;
    }

    if (file->header.magic.value != CAF_MAGIC_HEADER) {
        fclose(f);
        return CAF_INVALID_FILE;
    }

    caf_chunk chunk;
    enum caf_error err;

    while (!feof(f)) {
        if (fread(&chunk.chunk_id, sizeof(chunk.chunk_id), 1, f) != 1) break;
        if (fread(&chunk.chunk_size, sizeof(chunk.chunk_size), 1, f) != 1) {
            fclose(f);
            return CAF_ERROR;
        }

        switch (chunk.chunk_id.value) {
            case CAF_MAGIC_META:
                if (fread(&file->metadata, sizeof(caf_meta), 1, f) != 1) {
                    fclose(f);
                    return CAF_ERROR;
                }
                break;

            case CAF_MAGIC_DATA:
                file->num_samples = chunk.chunk_size / sizeof(int16_t);
                err = read_chunk_data(f, &chunk);
                if (err != CAF_OK) {
                    fclose(f);
                    return err;
                }
                file->samples = chunk.data.samples;
                break;

            default:
                fseek(f, chunk.chunk_size, SEEK_CUR);
                break;
        }
    }

    fclose(f);
    return CAF_OK;
}

enum caf_error caf_write(const caf_file *file, const char *filename) {
    FILE *f = fopen(filename, "wb");
    if (!f) return CAF_FILE_NOT_OPENED;

    if (fwrite(&file->header, sizeof(caf_header), 1, f) != 1) {
        fclose(f);
        return CAF_ERROR;
    }

    caf_chunk chunk;
    chunk.chunk_id.value = CAF_MAGIC_META;
    chunk.chunk_size = sizeof(caf_meta);

    if (fwrite(&chunk.chunk_id, sizeof(chunk.chunk_id), 1, f) != 1 ||
        fwrite(&chunk.chunk_size, sizeof(chunk.chunk_size), 1, f) != 1 ||
        fwrite(&file->metadata, sizeof(caf_meta), 1, f) != 1) {
        fclose(f);
        return CAF_ERROR;
    }

    chunk.chunk_id.value = CAF_MAGIC_DATA;
    chunk.chunk_size = file->num_samples * sizeof(int16_t);

    if (fwrite(&chunk.chunk_id, sizeof(chunk.chunk_id), 1, f) != 1 ||
        fwrite(&chunk.chunk_size, sizeof(chunk.chunk_size), 1, f) != 1 ||
        fwrite(file->samples, sizeof(int16_t), file->num_samples, f) != file->num_samples) {
        fclose(f);
        return CAF_ERROR;
    }

    fclose(f);
    return CAF_OK;
}

void caf_print_info(const caf_file *file) {
    printf("CAF File Information:\n");
    printf("Version: %u\n", file->header.version);
    printf("Channels: %u\n", file->header.channels);
    printf("Sample Rate: %u Hz\n", file->header.sample_rate);
    printf("Bits per Sample: %u\n", file->header.bits_per_sample);
    printf("\nMetadata:\n");
    printf("Title: %.32s\n", file->metadata.title);
    printf("Artist: %.32s\n", file->metadata.artist);
    printf("Year: %.4s\n", file->metadata.year);
}
