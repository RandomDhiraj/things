#!/usr/bin/env python3
# -*- coding: utf-8 -*-

from cme.cmedb import DatabaseNavigator


class navigator(DatabaseNavigator):
    pass
